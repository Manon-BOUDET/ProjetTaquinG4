/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projettaquin;

/**
 *
 * @author Manon
 */
public class IAConsole {
    
    public IAConsole(){
        
    }
    
    public IAConsole(Plateau plateau){
        
    }
    
    /*
        Affiche la case frontalière au crocodile sous forme de coordonné si celle ci est une gazelle
    */
    /*
    private boolean affichageSiPossibiliteEchanger(int ligne, int colonne, Plateau p) {
        if (p.getPlateau()[ligne][colonne].getPion().nom == 'G' && p.getPlateau()[ligne][colonne].getPion().retourner_sur_plateau == false) {
            System.out.println("Vous pouvez echanger le crocodile avec la Gazelle en (" + ligne + ";" + colonne + ")");
            return true;
        }
        return false;
    }
    */
    /*
        retourne un boolean en fonction de la réponse saisi par l'utilisateur
    */
    /*
    private boolean choixEchanger() {
        boolean b = false;
        while (b == false) {
            Scanner sc = new Scanner(System.in);
            String t = sc.nextLine();
            if (t.equals("oui")) {
                return true;
            }
            if (t.equals("non")) {
                return false;
            }
        }
        return false;
    }
    */
}

