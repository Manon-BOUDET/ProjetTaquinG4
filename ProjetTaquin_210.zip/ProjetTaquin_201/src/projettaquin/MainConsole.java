/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projettaquin;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author Manon
 */

public class MainConsole {

    public static void main(String[] args) throws InterruptedException {
        JeuConsole jeu = new JeuConsole();
        jeu.debutJeu();

    }

}