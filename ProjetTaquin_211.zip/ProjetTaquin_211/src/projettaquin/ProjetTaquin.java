/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projettaquin;

import java.util.Scanner;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Nicolas
 */
public class ProjetTaquin extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        boolean add = scene.getStylesheets().add("css/styles.css");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String t = "";
        while (t.equals("console") == false && t.equals("graphique") == false) { // gère le mode joueur ou ia
            System.out.println("Voulez vous jouer en mode console ou graphique ? (rentrer console ou graphique)");
            Scanner sc = new Scanner(System.in);
            t = sc.nextLine();
            if (t.equals("console")==true) {
                JeuConsole jeu = new JeuConsole();
                jeu.debutJeu();
            } else if (t.equals("graphique")==true) {
                launch(args);
            }
        }
    }
    
}
