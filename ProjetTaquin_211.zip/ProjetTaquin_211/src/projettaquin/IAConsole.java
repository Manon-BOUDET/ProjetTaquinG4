/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projettaquin;

import java.util.List;
import java.util.Scanner;
import projettaquin.Plateau;

/**
 *
 * @author Manon
 */
public class IAConsole {
    
    public IAConsole(){
        
    }
    
    public IAConsole(Plateau plateau){
        
    }
    
    // Affiche sous forme de coordonnée si une case est frontalière à la case vide 
    private boolean affichageSiPossibiliteEchanger(int ligne, int colonne, Plateau p) {
        List<Integer> vide = p.rechercheVide(p);
        int lVide = vide.get(0); // Ligne de la case vide
        int cVide = vide.get(1); // Colonne de la case vide
        if (((lVide == ligne)&& (colonne == cVide -1))||((lVide == ligne)&&(colonne == cVide +1))||((lVide +1 == ligne)&&(colonne == cVide))||((lVide -1 == ligne)&&(colonne == cVide))){
            System.out.println("Vous pouvez echanger la case vide avec (" + ligne + ";" + colonne + ")");
            return true;
        } else {
            System.out.println("Déplacement impossible.");
            return false;
        }
    }
    
    // Retourne un boolean en fonction de la réponse saisi par l'utilisateur
    private boolean choixEchanger() {
        boolean b = false;
        while (b == false) {
            Scanner sc = new Scanner(System.in);
            String t = sc.nextLine();
            if (t.equals("oui")) {
                return true;
            }
            if (t.equals("non")) {
                return false;
            }
        }
        return false;
    }
}

