package projettaquin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
//import javafx.scene.paint.Color;
//import javafx.scene.text.Font;

/**
 *
 * @author Nicolas
 */
public class FXMLDocumentController implements Initializable {
    /*
     * Variables globales correspondant à des objets définis dans la vue (fichier .fxml)
     * Ces variables sont ajoutées à la main et portent le même nom que les fx:id dans Scene Builder
     */
    
    @FXML
    private GridPane grille; // plateau de jeu
    @FXML
    private Pane fond; // panneau recouvrant toute la fenêtre

    
    public void initialisation2(){
        // Pour chaques cases du plateau, on va créer une tuile qui contiendra un label représentant un numéro.
        // On initialise ici la grille réussie (donc valide).
        int col,line,i = 0;
        for (col=0;col<=3;col++){
            for (line=0; line<=3 ;line++){
                if (col==3 && line==3){
                    break;
                }
                i = (1+col) + (4*line);
                Pane paneTuile = new Pane();
                paneTuile.setPrefSize(100,100);
                Label num = new Label(Integer.toString(i));
                paneTuile.getStyleClass().add("pane"); // On applique à l'objet le style css correspondant
                num.getStyleClass().add("tuile"); // On applique à l'objet le style css correspondant
                grille.add(paneTuile, col, line);
                GridPane.setHalignment(num, HPos.CENTER);
                paneTuile.getChildren().add(num);
                if (i>=10){ // Lorsque le label contient deux chiffres, on décale le texte pour le recentrer sur la case
                num.setTranslateX(-10);
                }
            }
        }
        // Test pour renvoyer la valeur d'une case du tableau et la comparer à une autre valeur.
        Label label = getLabel(getPaneByRowColumnIndex(grille,2,2));
        String numero = label.getText();
        if ("11".equals(numero)){
            System.out.println("C'est égal");
        }
        else {
            System.out.println("Ce n'est pas égal");
        }
         
         System.out.println(numero);
    }
    
    public Pane getPaneByRowColumnIndex(GridPane grille, final int row, final int column) {
        // Retourne le Pane (la case) positionnée à la ligne "row" et la colonne "column".
        // On va donc parcourir la liste des enfants de la grille, sélectionner celui qui correspond à la bonne position et le convertir en Pane.
        Node result = null;
        ObservableList<Node> children = grille.getChildren();
        children.remove(0);
        for (Node node : children) {
            if((grille.getRowIndex(node) == row) && (grille.getColumnIndex(node) == column)) {
                result = node;
                break;
            }
        }
        return (Pane)result;
    }
    
    public Label getLabel(Pane pane) {
        // Retourne le Label (le numéro) d'une case.
        // On va parcourir la liste des enfants de la case, mais pour une case on a qu'un enfant (on a un seul numéro par case)
        // donc on va le récupérer et le convertir en Label.
        Node result = null;
        ObservableList<Node> children = pane.getChildren();
        for (Node node : children) {
                result = node;
                break;
        }
        return (Label)result;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // initialisation de la grille
        grille.getStyleClass().add("gridpane"); // On applique à l'objet le style css correspondant
        initialisation2();
    }
    
    
    @FXML
    private void handleButtonActionAide(MouseEvent event) {
        System.out.println("Activation de l'aide");
    }
    
    @FXML
    private void handleButtonActionMelange(MouseEvent event) {
        System.out.println("Activation de la réinitialisation de grille");
    }
}
