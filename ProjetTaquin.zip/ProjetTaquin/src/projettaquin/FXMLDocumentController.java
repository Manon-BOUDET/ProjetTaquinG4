package projettaquin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
//import javafx.scene.paint.Color;
//import javafx.scene.text.Font;

/**
 *
 * @author Nicolas
 */
public class FXMLDocumentController implements Initializable {
    /*
     * Variables globales correspondant à des objets définis dans la vue (fichier .fxml)
     * Ces variables sont ajoutées à la main et portent le même nom que les fx:id dans Scene Builder
     */
    
    @FXML
    private GridPane grille;
    @FXML
    private Pane fond; // panneau recouvrant toute la fenêtre

    // variables globales non définies dans la vue (fichier .fxml)
    //private final Pane p = new Pane(); // panneau utilisé pour dessiner une tuile "2"
    //private final Label c = new Label("2");
    private double x = 24.0, y = 191.0;
    
    public void initialisationGrille(){
        int i = 1;
        double xi;
        double yi;
        while (i<=15){
            xi = x;
            yi = y;
            Pane paneTuile = new Pane();
            paneTuile.setPrefSize(100,100);
            Label num = new Label(Integer.toString(i));
            paneTuile.getStyleClass().add("pane"); 
            num.getStyleClass().add("tuile");
            if (i<5){
                xi = xi + (i-1)*(397/4);
                
            }
            else if ( i >= 5 && i < 9){
                xi = xi + (i-5)*(397/4);
                yi = yi + (397/4);
            }
            else if ( i >= 9 && i < 13){
                xi = xi + (i-9)*(397/4);
                yi = yi + 2*(397/4);
            }
            else if ( i >= 13 && i < 16){
                xi = xi + (i-13)*(397/4);
                yi = yi + 3*(397/4);
            }
            System.out.println("La case "+i+" a x = "+xi+" et y = "+yi+" ");
            
            GridPane.setHalignment(num, HPos.CENTER);
            fond.getChildren().add(paneTuile);
            paneTuile.getChildren().add(num);
            if (i>=10){
                num.setTranslateX(-10);
            }
            
            paneTuile.setLayoutX(xi);
            paneTuile.setLayoutY(yi);
            paneTuile.setVisible(true);
            num.setVisible(true);
           
            i++;
        }
    }
    public void initialisation2(){
        int col,line,i = 0;
        for (col=0;col<=3;col++){
            for (line=0; line<=3 ;line++){
                if (col==3 && line==3){
                    break;
                }
                i = (1+col) + (4*line);
                Pane paneTuile = new Pane();
                paneTuile.setPrefSize(100,100);
                Label num = new Label(Integer.toString(i));
                paneTuile.getStyleClass().add("pane"); 
                num.getStyleClass().add("tuile");
                grille.add(paneTuile, col, line);
                GridPane.setHalignment(num, HPos.CENTER);
                paneTuile.getChildren().add(num);
                if (i>=10){
                num.setTranslateX(-10);
                
                }
                //System.out.println(paneTuile.getChildren());
                
                
                
            }
            
        }
        //System.out.println(grille.getChildren());
        
    }
    
    public Node getNodeByRowColumnIndex(final int row, final int column) {
        Node result = null;
        ObservableList<Node> children = grille.getChildren();

        for (Node node : children) {
            if(grille.getRowIndex(node) == row && grille.getColumnIndex(node) == column) {
                result = node;
                break;
            }
        }
           
        return result;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // utilisation de styles pour la grille et la tuile (voir styles.css)
        //p.getStyleClass().add("pane"); 
        //c.getStyleClass().add("tuile");
        grille.getStyleClass().add("gridpane");
        initialisation2();
        
        
        //getNodeByRowColumnIndex(1,1);
        //System.out.println(node);
        
        //GridPane.setHalignment(c, HPos.CENTER);
        //fond.getChildren().add(p);
        //p.getChildren().add(c);

        // on place la tuile en précisant les coordonnées (x,y) du coin supérieur gauche
        //p.setLayoutX(x);
        //p.setLayoutY(y);
        //p.setVisible(true);
        //c.setVisible(true);
    }
    
    
    @FXML
    private void handleButtonActionAide(MouseEvent event) {
        System.out.println("Activation de l'aide");
    }
    
    @FXML
    private void handleButtonActionMelange(MouseEvent event) {
        System.out.println("Activation de la réinitialisation de grille");
    }
}
