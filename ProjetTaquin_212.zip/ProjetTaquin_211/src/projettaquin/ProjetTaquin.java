
package projettaquin;

import java.util.Scanner;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author @author Nicolas DAVID, Manon BOUDET et Eléonore GUISE
 * @version 2.1.2
 */
public class ProjetTaquin extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        boolean add = scene.getStylesheets().add("css/styles.css");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Il s'agit du main de l'application.
        // On demande au joueur si il veut jouer en console ou graphique et on lance le mode correspondant à son choix.
        String t = "";
        while (t.equals("console") == false && t.equals("graphique") == false) { 
            System.out.println("Voulez vous jouer en mode console ou graphique ? (rentrer console ou graphique)");
            Scanner sc = new Scanner(System.in);
            t = sc.nextLine();
            if (t.equals("console")==true) {
                JeuConsole jeu = new JeuConsole();
                jeu.debutJeu();
            } else if (t.equals("graphique")==true) {
                launch(args);
            }
        }
    }
    
}
