package projettaquin;

import com.sun.deploy.util.StringUtils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import static java.lang.System.exit;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
//import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
//import javafx.scene.layout.Priority;
//import javafx.scene.layout.RowConstraints;
//import javafx.scene.paint.Color;
//import javafx.scene.text.Font;


/**
 *
 * @author @author Nicolas DAVID, Manon BOUDET et Eléonore GUISE
 * @version 2.1.2
 */
public class FXMLDocumentController implements Initializable {

    /*
     * Variables globales correspondant à des objets définis dans la vue (fichier .fxml)
     * Ces variables sont ajoutées à la main et portent le même nom que les fx:id dans Scene Builder
     */
    @FXML
    private GridPane grille; // plateau de jeu
    @FXML
    private Pane fond; // panneau recouvrant toute la fenêtre
    @FXML
    private Label labelWin; // Message de victoire
    @FXML
    private Label labelScore; // Affichage du score de la partie en cours
    private int score, record = 0; // Score de la partie en cours et meilleur score du joueur toutes parties confondues.
    
    public void initialisation() {
        // Pour chaques cases du plateau, on va créer une tuile qui contiendra un label représentant un numéro.
        // On initialise ici la grille réussie (donc valide).        
        int col, line, i = 0;
        for (col = 0; col <= 3; col++) {
            for (line = 0; line <= 3; line++) {
                if (col == 3 && line == 3) {
                    Pane paneTuile = new Pane();
                    paneTuile.setPrefSize(100, 100);
                    Label num = new Label(null);
                    grille.add(paneTuile, col, line);
                    paneTuile.getChildren().add(num);
                    break;
                }
                i = (1 + col) + (4 * line);
                Pane paneTuile = new Pane();
                paneTuile.setPrefSize(100, 100);
                GridPane grilleInit = grille;
                paneTuile.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() { // Lorsque l'utilisateur clique sur une tuile, on la déplace (si possible)
                    public void handle(final MouseEvent mouseEvent) {
                        Node source = (Node) mouseEvent.getSource();
                        Integer colIndex = GridPane.getColumnIndex(source);
                        Integer rowIndex = GridPane.getRowIndex(source);
                        
                        deplacementSimple(rowIndex,colIndex);
                        finPartie();
                    }
                });
                grille.addEventHandler(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
                    public void handle(final KeyEvent keyEvent) {
                        if (keyEvent.getText() == "k"){
                            System.out.println("k pressed");
        }
                    }
                });

                Label num = new Label(Integer.toString(i));

                paneTuile.getStyleClass().add("pane"); // On applique à l'objet le style css correspondant
                num.getStyleClass().add("tuile"); // On applique à l'objet le style css correspondant
                grille.add(paneTuile, col, line);
                GridPane.setHalignment(num, HPos.CENTER);
                paneTuile.getChildren().add(num);
                if (i >= 10) { // Lorsque le label contient deux chiffres, on décale le texte pour le recentrer sur la case
                    num.setTranslateX(-10);
                }
            }
        }
        
    }

    public void deplacement(GridPane grille,Pane pane,final int row,final int column) {
        // Echange la position de deux cases (nodes).
        Node node = (Node) pane;
        Node nodeFinal = (Node) getPaneByRowColumnIndex(grille,row,column);
        int ligneDepart = grille.getRowIndex(node);
        int colonneDepart = grille.getColumnIndex(node);
        grille.setColumnIndex(node,column);
        grille.setRowIndex(node,row);
        grille.setColumnIndex(nodeFinal,colonneDepart);
        grille.setRowIndex(nodeFinal,ligneDepart);
    }
    
    public void deplacementSimple(int row, int col){
        //Permet de déplacer de déplacer une tuile en l'échangeant avec la tuile vide, si la tuile vide se situe immédiatement en haut, en bas, à gauche ou à droite de notre tuile.
        //Sinon si la tuile est sur la même ligne ou la même colonne, on apelle deplacementMultiple pour effectuer un déplacement de ligne ou colonne.
        List<Integer> vide = rechercheVide(grille);
        int rowVide = vide.get(0);
        int colVide = vide.get(1);
        if (((rowVide == row)&& (col == colVide -1))||((rowVide == row)&&(col == colVide +1))||((rowVide +1 == row)&&(col == colVide))||((rowVide -1 == row)&&(col == colVide))){
            deplacement(grille,getPaneByRowColumnIndex(grille,row,col),rowVide,colVide);
            score +=1;
            labelScore.setText(Integer.toString(score));
        }
        else if((row==rowVide)||(col==colVide)){
            
            deplacementMultiple(row,col,rowVide,colVide);
            score +=1;
            labelScore.setText(Integer.toString(score));
        }
        
    }
    
    public void deplacementMultiple(int row, int col, int rowVide, int colVide){
        // Si la ligne (ou colonne)de la case est la même que la ligne (ou colonne) de la case vide, on effectue le nombre de déplacements simples nécessaire.
        if(row == rowVide){
            int ecart = colVide - col;
            if(ecart >0){
                for (int i = 0;i<ecart;i++){
                    deplacementSimple(row,colVide-i-1);
                    score -=1;
                    labelScore.setText(Integer.toString(score));
                }
            }
            if(ecart < 0){
                ecart = -ecart;
                for (int i = 0;i<ecart;i++){
                    deplacementSimple(row,colVide+i+1);
                    score -=1;
                    labelScore.setText(Integer.toString(score));
                } 
            }
        }
        if(col == colVide){
            int ecart = rowVide - row;
            if(ecart >0){
                for (int i = 0;i<ecart;i++){
                    deplacementSimple(rowVide-i-1,col);
                    score -=1;
                    labelScore.setText(Integer.toString(score));
                }
            }
            if(ecart < 0){
                ecart = -ecart;
                for (int i = 0;i<ecart;i++){
                    deplacementSimple(rowVide+i+1,col);
                    score -=1;
                    labelScore.setText(Integer.toString(score));
                } 
            }
        }
    }

    public List<Integer> rechercheVide(GridPane grille) {
        // Retourne les coordonnées (ligne et colonne) de la case vide dans une ArrayList.
        List<Integer> coordonnees = new ArrayList<Integer>();
        int row = 0, column= 0;
        Node result = null;
        ObservableList<Node> children = grille.getChildren();
        if (children.size() > 16) {
            children.remove(0);
        }
        for (Node node: children) {
            if (getLabel((Pane) node).getText() == null) {
                result = node;
                break;

            }
        }
        row = grille.getRowIndex(result);
        column = grille.getColumnIndex(result);
        coordonnees.add(row);
        coordonnees.add(column);
        return coordonnees;
    }

    public Pane getPaneByRowColumnIndex(GridPane grille,final int row,final int column) {
        // Retourne le Pane (la case) positionnée à la ligne "row" et la colonne "column".
        // On va donc parcourir la liste des enfants de la grille, sélectionner celui qui correspond à la bonne position et le convertir en Pane.
        Node result = null;
        ObservableList<Node> children = grille.getChildren();
        if (children.size() > 16) {
            children.remove(0);
        }
        for (Node node: children) {
            if ((grille.getRowIndex(node) == row) && (grille.getColumnIndex(node) == column)) {
                result = node;
                break;
            }
        }
        return (Pane) result;
    }

    public Label getLabel(Pane pane) {
        // Retourne le Label (le numéro) d'une case.
        // On va parcourir la liste des enfants de la case, mais pour une case on a qu'un enfant (on a un seul numéro par case)
        // donc on va le récupérer et le convertir en Label.
        Node result = null;
        ObservableList<Node> children = pane.getChildren();
        for (Node node : children) {
            result = node;
            break;
        }
        return (Label) result;

    }
    
    public void finPartie(){
        //Vérifie que les conditions de fin de partie sont vérifiées. Si toutes les tuiles sont bien placées, on modifie le Label de fin de partie pour qu'il affiche "Bravo, vous avez gagné !"
        List<Integer> vide = rechercheVide(grille);
        int rowVide = vide.get(0);
        int colVide = vide.get(1);
        if (rowVide == 3 && colVide ==3){
            int bonnePos = 0;
            for (int i=0;i<4;i++){
                for (int j=0;j<4;j++){
                    if (i != 3 || j !=3){
                        Pane tuile = getPaneByRowColumnIndex(grille, i, j);
                        Label label = getLabel(tuile);
                        int numero = Integer.parseInt(label.getText());
                        if ((1 + j) + (4 * i) == numero) {
                            
                            bonnePos +=1;
                        }else {
                            
                        }
                    }  
                }
            }
            if (bonnePos == 15){
                
                labelWin.setText("Bravo !!");
                return;
            }
        } 
        
        labelWin.setText("");
    }
    
    public void melanger(){
        //Permet de mélanger la grille par une succession de 500 déplacements simples dans des directions aléatoires.
        for (int i=0;i<500;i++){
           List<Integer> vide = rechercheVide(grille);
            int rowVide = vide.get(0);
            int colVide = vide.get(1);
            int random = (int)(Math.random() * 4);
            if ((random == 0)&&(rowVide>0)){
                deplacementSimple(rowVide -1,colVide);
            }
            else if ((random == 1)&&(rowVide<3)){
                deplacementSimple(rowVide +1,colVide);
            }
            else if ((random == 2)&&(colVide>0)){
                deplacementSimple(rowVide,colVide -1);
            }
            else if ((random == 3)&&(colVide<3)){
                deplacementSimple(rowVide,colVide +1);
            }
        }
        score=0;
        labelScore.setText(Integer.toString(score));
    }

    
    public void save(String fileName) throws IOException {
		//Sauvegarde la partie en cours dans un fichier texte.
		System.out.println("Saving ...");
		Path file = Paths.get(fileName);
		try (BufferedWriter writer = Files.newBufferedWriter(file)) {
			writer.write(score + "");
			writer.newLine();
			writer.write(record + "");
			List<Integer> vide = rechercheVide(grille);
                        int rowVide = vide.get(0);
                        int colVide = vide.get(1);
			for (int i = 0; i <=3; i++) {
				writer.newLine();
				for (int j = 0; j <=3; j++) {
                                    if(i==rowVide && j == colVide){
                                        writer.write("0 ");
                                    }
                                    else{
                                        Pane tuile = getPaneByRowColumnIndex(grille, i, j);
                                        Label label = getLabel(tuile);
                                        String numero = label.getText()+" ";
                                        writer.write(numero);
                                    }
                                    
				}
			}
			System.out.println("Saved");
		} catch (IOException e) {
			e.printStackTrace();
                        
		}
	}
    
    public void load(String fileName) throws IOException {
		//permet de charger une partie enregistrée dans un fichier texte
		System.out.println("Loadind ...");
		String line;
		Path file = Paths.get(fileName);
		try (BufferedReader reader = Files.newBufferedReader(file)) {
			line = reader.readLine();
			int score = Integer.parseInt(line);
			line = reader.readLine();
			int record = Integer.parseInt(line);
			line = reader.readLine();
			for (int i = 0; i < 3; i++) {
                            int nb;
                            //nb = StringUtils.countMatches(line, " ");
                            
                            line = reader.readLine();
			}
			System.out.println("Loaded");
			
		}
	}
    

/* IA 
    public void aide(){ // La méthode aide ne renvoie rien 
        List<Integer> coordonnees = new ArrayList<Integer>();
        coordonnees = premposition(); // L'attribut "coordonnees" prend les coordonnées de la première position de la tuile qui est mal placé
        int i = coordonnees.get(0); // Ligne de la première position de la tuile qui est mal placé
        int j = coordonnees.get(1); // Colonne de la première position de la tuile qui est mal placé
        List<Integer> coordonneesVide = new ArrayList<Integer>(); 
        coordonneesVide = rechercheVide(grille); // L'attribut "coordonneesVide" prend les coordonnées de la tuile Vide
        int iVide = coordonneesVide.get(0); // Ligne de la tuile Vide
        int jVide = coordonneesVide.get(1); // Colonne de la tuile Vide

        Pane tuileA = getPaneByRowColumnIndex(grille, 3, 3);
        tuileA.getStyleClass().add("aide"); // Après avoir appuyer sur le bouton "Aide", on applique à la case qu'on doit échanger un style css "aide" pour indiquer le déplacement.
        // ?
        //tuileA.getStyleClass().add("pane")
    }
    
    // La méthode premposition retourne les coordonnées de la première position de la tuile qui est mal placé.
    public List<Integer> premposition(){
        if (finPartie()==true){ // Si la partie est déjà finie
            System.out.println("test 1");
            return null;
        }
        List<Integer> coordonnees = new ArrayList<Integer>();
        List<Integer> vide = rechercheVide(grille); // On recherche où est la case vide
        int rowVide = vide.get(0); // On recupère sa ligne
        int colVide = vide.get(1); // On recupère sa colonne
        for (int i=0;i<4;i++){ // On commence par les lignes du jeu
            for (int j=0;j<4;j++){ // Puis pour chaque ligne on parcourt les colonnes du jeu
                if (i == rowVide && j == colVide) { // Si la ligne et la colonne où on est sont égales aux coordonnées de la tuile vide
                    coordonnees.add(rowVide);
                    coordonnees.add(colVide);
                    return coordonnees; // retourne les coordonnées de la tuile vide
                } else {
                    Pane tuile = getPaneByRowColumnIndex(grille, i, j);
                    Label label = getLabel(tuile);
                    int numero = Integer.parseInt(label.getText());
                    if ((1 + j) + (4 * i) != numero) {
                        coordonnees.add(i);
                        coordonnees.add(j);
                        return coordonnees;
                    }
                } 
            }
        }
        System.out.println("test 2");
        return null;
    }
    /* Utilise la fonction getLabel(Pane pane) pour trouver le Label (le numéro) d'une case et
    la fonction getPaneByRowColumnIndex(GridPane grille,final int row,final int column)
    */
    
    // Recherche les coordonnées de la tuile qui doit aller à la place de la tuile mal placé
    /*public List<Integer> rechercheTuile(){
        
    }*/

    
    @Override
    public void initialize(URL url,ResourceBundle rb) {
        // initialisation de la grille, mélange de la grille et initialisation du label de fin de partie.
        grille.getStyleClass().add("gridpane"); // On applique à l'objet le style css correspondant
        initialisation();
        melanger();
        labelWin.setText("");
    }

    @FXML
    private void handleButtonActionAide(MouseEvent event) {
        System.out.println("Activation de l'aide");
    }

    @FXML
    private void handleButtonActionMelange(MouseEvent event) {
        //Action réalisée lorsque le joueur clique sur le bouton "Réinitialiser la grille".
        //On mélange la grille et on efface le texte du Label "Bravo, vous avez gagné".
        System.out.println("Activation de la réinitialisation de grille");
        melanger();
        labelWin.setText("");
    }
    
    @FXML
    private void quitter(MouseEvent event) {
        //Lorsque nous cliquons sur le bouton "quitter", on sauvegarde la partie dans un fichier texte.
        try {
            save("save");
	} catch (IOException e) {
            e.printStackTrace();
	}
    }
    @FXML
    private void deplacementTouches(KeyEvent event){
        if (event.getText() == "k"){
            System.out.println("k pressed");
        }
    }
}
